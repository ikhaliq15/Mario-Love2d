function love.conf(t)
	t.title = "Super Mario Bros"		    -- The title of the window the game is in (string)
    -- t.window.width = 25 * 32		    -- The window width (number)
    -- t.window.height = 18 * 32			    -- The window height (number)
    t.window.width = 256 * 2		    -- The window width (number)
    t.window.height = 224 * 2			    -- The window height (number)
    t.window.fullscreen = false		-- Enable fullscreen (boolean)
    t.console = false
end